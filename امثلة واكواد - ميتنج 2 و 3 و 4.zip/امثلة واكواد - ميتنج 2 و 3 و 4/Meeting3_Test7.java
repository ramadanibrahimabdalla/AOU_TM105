

/**
    TM105 - Meeting 3
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting3_Test7 {
    public static void main(String[] args) {
        double t, c, f;
        char unit;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the temprature: ");
        t = s.nextDouble();
        System.out.print("Enter the unit(C or F): ");
        unit = s.next().charAt(0);
        if(unit == 'C'){
            f = 9.0 / 5 * t +32;
            System.out.printf("%.2f Celsuis is %.2f Fahernheit", t, f);
        }else if(unit == 'F'){
            c = 5.0 / 9 * (t - 32);
            System.out.printf("%.2f Fahenheit is %.2f Celsuis", t, c);
        }else{
            System.out.println("Invalid input");
        }
    }
}
