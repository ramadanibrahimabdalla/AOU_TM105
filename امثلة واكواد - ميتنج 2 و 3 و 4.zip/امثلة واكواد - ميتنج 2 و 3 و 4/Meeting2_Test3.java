/**
    TM105 - Meeting 2
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

public class Test3 {

    public static void main(String[] args) {

        System.out.println( 3 + 4 ); // addition operator

        System.out.println("Sum = " + 117); // concate operator

        System.out.println("Sum = " + 3 + 4 ); // concate operator

        System.out.println("Sum = " +  ( 3 + 4 )); // 1-concate : 2- addition

        System.out.println( 3 + 4 + " = sum");  //1- addition : 2- cocate

    }

}
