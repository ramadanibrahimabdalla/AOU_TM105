
/**
    TM105 - Meeting 3
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting3_Test1 {
    public static void main(String[] args) {
        int number;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter number: ");
        number = s.nextInt();
        if(number % 5 == 0){
            System.out.println("OK");
        }else{
            System.out.println("Sorry");
        }
    }
}
