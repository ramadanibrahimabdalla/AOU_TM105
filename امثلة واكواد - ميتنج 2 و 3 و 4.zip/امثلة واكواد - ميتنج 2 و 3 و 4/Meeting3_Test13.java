
/**
    TM105 - Meeting 3
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/


import java.util.Scanner;
public class Meeting3_Test13 {
    public static void main(String[] args) {
        int age = 0, count = 0;
        Scanner s = new Scanner(System.in);
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter age: ");
            age = s.nextInt();
            if(age > 18 && age < 40){
                count++;
            }
        }
        System.out.println("Count = " + count);
    }
}
