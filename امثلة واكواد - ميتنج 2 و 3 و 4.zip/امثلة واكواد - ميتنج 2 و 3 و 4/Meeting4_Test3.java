
/**
    TM105 - Meeting 4
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/


import java.util.Scanner;
public class Meeting4_Test3 {
    public static void main(String[] args) {
        int n = 0, value = 0, count = 0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the number of values: ");
        n = s.nextInt();
        System.out.print("Enter the values: ");
        for (int i = 0; i < n; i++) {
            value = s.nextInt();
            if(value % 2 == 0 && value % 3 == 0){
                count++;
            }
        }
        System.out.println("The number of values divisible by both 2 and 3 = " + count);
    }
}
