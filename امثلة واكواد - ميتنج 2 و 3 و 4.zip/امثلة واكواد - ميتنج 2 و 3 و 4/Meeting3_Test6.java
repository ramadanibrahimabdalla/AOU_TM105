
/**
    TM105 - Meeting 3
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting3_Test6 {
    public static void main(String[] args) {
        int day;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter day: ");
        day = s.nextInt();
        if(day == 1){
            System.out.println("Satuerday");
        }else if(day == 2){
            System.out.println("Sunday");
        }else if(day == 3){
            System.out.println("Monday");
        }else if( day == 4){
            System.out.println("Tuesday");
        }else if( day == 5){
            System.out.println("Wednesday");
        }else if(day == 6){
            System.out.println("Thuersady");
        }else if(day == 7){
            System.out.println("Friday");
        }else{
            System.out.println("Invalid day");
        }
    }
}
