
/**
    TM105 - Meeting 4
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting4_Test5 {
    public static void main(String[] args) {
        int x = 0, y = 0, count = 0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the start value: ");
        x = s.nextInt();
        System.out.print("Enter the end value: ");
        y = s.nextInt();

        for (int i = x; i < y; i++) {

            if(i % 5 == 0){
                count++;
                System.out.println(i);
            }

        }

        System.out.print("Sum of the even values between them is: " + count);

    }
}
