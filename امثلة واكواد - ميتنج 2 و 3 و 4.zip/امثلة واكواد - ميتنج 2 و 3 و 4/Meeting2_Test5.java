/**
    TM105 - Meeting 2
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Test5 {
    public static void main(String[] args) {
        double length, width, perimeter;
        Scanner s = new Scanner(System.in);
        System.out.println("Enter length: ");
        length = s.nextDouble();
        System.out.println("Enter width: ");
        width = s.nextDouble();
        perimeter = 2 * (length + width);
        System.out.printf("The value of perimeter = %.2f", perimeter);
    }
}



