
/**
    TM105 - Meeting 3
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting3_Test9 {
    public static void main(String[] args) {
        int a = 3;

        int b = a++ + 5;

        System.out.println("b = " + b);

        System.out.println("a = " + a );
    }
}
