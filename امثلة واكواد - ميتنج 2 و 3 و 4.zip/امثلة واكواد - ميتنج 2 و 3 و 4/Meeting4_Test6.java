

/**
    TM105 - Meeting 4
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting4_Test6 {
    public static void main(String[] args) {
        double gpa = 0, average = 0 , sum = 0;
        int count = 0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the GPA of the students or -1 to stop the program: ");
        gpa = s.nextDouble();
        while(gpa != -1){
            sum = sum + gpa;
            count++;
            gpa = s.nextDouble();
        }
        average = sum / count;
        System.out.printf("GPA avereage of the class = %.2f", average);
    }
}
