
/**
    TM105 - Meeting 4
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting6_Test8 {
    public static void main(String[] args) {
        String myName = "", friendName = "";
        int count = 0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter your first name: ");
        myName = s.next();
        System.out.println("Please, insert the first name of your friends or stop to stop your program: ");
        friendName = s.next();
        while (!friendName.equals("stop")){
            if(friendName.equals(myName)){
                count++;
            }
            friendName = s.next();
        }
        System.out.println(count + " of your frinds their first name identical to your first name");
    }
}
