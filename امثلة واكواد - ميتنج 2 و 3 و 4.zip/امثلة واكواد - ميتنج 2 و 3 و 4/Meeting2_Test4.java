
/**
    TM105 - Meeting 2
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

public class Test4 {
    public static void main(String[] args) {
        char c = 'a';
        System.out.printf("%c\n", c);

        int i = 3;
        System.out.printf("%d\n", i);

        double d = 3.536176;
        System.out.printf("%.2f\n", d);

        String name = "ali";
        System.out.printf("Your name is %s\n", name);
    }
}
