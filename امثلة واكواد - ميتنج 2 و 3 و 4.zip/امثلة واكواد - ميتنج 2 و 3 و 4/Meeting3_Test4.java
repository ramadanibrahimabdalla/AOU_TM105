
/**
    TM105 - Meeting 3
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting3_Test4 {
    public static void main(String[] args) {
        int score;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter score: ");
        score = s.nextInt();
        if(score >= 0 && score <= 100){
            System.out.println("Valid score");
        }else{
            System.out.println("Invalid score");
        }
    }
}




