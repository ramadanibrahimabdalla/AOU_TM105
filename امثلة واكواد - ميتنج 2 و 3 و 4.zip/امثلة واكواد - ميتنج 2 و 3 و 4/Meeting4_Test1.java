
/**
    TM105 - Meeting 4
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting4_Test1 {
    public static void main(String[] args) {
        int score = 0, min = 1000;
        Scanner s = new Scanner(System.in);
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter score: ");
            score = s.nextInt();
            if(score < min){
                min = score;
            }
        }
        System.out.println("Min = " + min);
    }
}
