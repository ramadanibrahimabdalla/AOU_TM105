
/**
    TM105 - Meeting 4
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/


import java.util.Scanner;
public class Meeting4_Test7 {
    public static void main(String[] args) {
        char c = ' ';
        int count = 0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the characters or z to stop the program: ");
        c = s.next().charAt(0);
        while (c != 'z'){
            if(c == 'a' || c == 'o' || c == 'u' || c == 'i' || c == 'y'){
                count++;
            }
            c = s.next().charAt(0);
        }
        System.out.println("The number of the vowel letters are: " + count);
    }
}
