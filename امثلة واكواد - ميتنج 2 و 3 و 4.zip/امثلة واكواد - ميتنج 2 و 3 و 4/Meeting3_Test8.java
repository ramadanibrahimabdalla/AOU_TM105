
/**
    TM105 - Meeting 3
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting3_Test8 {
    public static void main(String[] args) {
        String mName, fName;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter your name: ");
        mName = s.next();
        System.out.print("Enter your freind name: ");
        fName = s.next();
        if(mName.equals(fName) == true){
            System.out.println("OK");
        }else{
            System.out.println("Sorry");
        }
    }
}
