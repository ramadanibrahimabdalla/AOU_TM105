/**
    TM105 - Meeting 2
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/
public class Test {
    public static void main(String[] args) {
        //Declaration:
        int number1, number2, sum;
        //Initialization:
        number1 = 10;
        number2 = 20;
        //Find sum:
        sum = number1 + number2;
        //Print sum:
        System.out.println(sum);
    }
}
