/**
    TM105 - Meeting 3
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting3_Test3 {
    public static void main(String[] args) {
        char c;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter c: ");
        c = s.next().charAt(0);
        if(c == 'a' || c == 'i' || c == 'o' ||
        c == 'u' || c == 'y'){
            System.out.println("Vowel letter");
        }else{
            System.out.println("Non-Vowel letter");
        }
    }
}
