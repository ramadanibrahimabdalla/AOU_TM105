
/**
    TM105 - Meeting 2
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Test6 {
    public static void main(String[] args) {
        double radius, area;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter radius: ");
        radius = s.nextDouble();
        if(radius > 0){
            area = 3.14 * radius * radius;
            System.out.println("area = " + area);
        }else{
            System.out.println("Wrong radius");
        }
    }
}
