
/**
    TM105 - Meeting 3
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting3_Test11 {
    public static void main(String[] args) {
        double temp = 0;
        int countPositive = 0, countNegative = 0, countZeros = 0;
        Scanner s = new Scanner(System.in);
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter the tempratures: ");
            temp = s.nextDouble();
            if(temp > 0){
                countPositive++;
            }else if(temp < 0){
                countNegative++;
            }else{
                countZeros++;
            }
        }
        System.out.println("The number of positive tempratures are: " + countPositive);
        System.out.println("The number of negative tempratures are: " + countNegative);
        System.out.println("The number of zeros tempratures are: " + countZeros);
    }
}
