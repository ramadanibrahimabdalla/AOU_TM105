
/**
    TM105 - Meeting 4
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/


import java.util.Scanner;
public class Meeting4_Test2 {
    public static void main(String[] args) {
        int n = 0, temp = 0, count = 0;
        Scanner s = new Scanner(System.in);
        System.out.print("Enter n: ");
        n = s.nextInt();
        System.out.print("Enter a temprature: ");
        for (int i = 0; i < n; i++) {
            temp = s.nextInt();
            if(temp < 0){
                count++;
            }
        }
        System.out.println("The number of negative tempratures are: " + count);
    }
}
