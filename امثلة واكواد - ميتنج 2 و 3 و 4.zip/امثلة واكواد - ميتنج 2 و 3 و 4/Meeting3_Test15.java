
/**
    TM105 - Meeting 3
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

import java.util.Scanner;
public class Meeting3_Test15 {
    public static void main(String[] args) {
        int age = 0, sum = 0;
        Scanner s = new Scanner(System.in);
        for (int i = 0; i < 10; i++) {
            System.out.print("Enter age: ");
            age = s.nextInt();
            sum = sum + age;
        }
        System.out.println("Total ages = " + sum);
    }
}
