
/**
    TM105 - Meeting 2
    This code is written by Eng. Ramadan Ibrahim
    WhatsApp: 00201024805965
*/

public class CompilationError {

    public static void main(String[] args) {

        int grade = 30;
        if(grade >= 50); {
            System.out.println("pass");
        }else{
            System.out.println("fail");
        }
    }
}
