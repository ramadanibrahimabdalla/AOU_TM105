public class TestStudent {
    public static void main(String[] args) {
        Student s1 = new Student(100, "ahmed", 70, 'm');
        System.out.println(s1.getId());
        System.out.println(s1.getName());
        System.out.println(s1.getScore());
        System.out.println(s1.getGeneder());
        System.out.println(s1.toString());
        s1.setScore(65);
        System.out.println(s1.toString());
        Student s2 = new Student(200, "ahmed", 65, 'm');
        System.out.println(s2.toString());
        if(s1.equals(s2) == true){
            System.out.println("s1 eqauls s2");
        }else{
            System.out.println("s1 does not equal s2");
        }
        System.out.println(s1.finalResult());
    }
}
