public class PC {
    //attributes:
    private String brand;
    private int ramSize;

    //constructors:
    public PC(){
        this.brand = null;
        this.ramSize = 0;
    }

    public PC(String brand, int ramSize){
        this.brand = brand;
        this.ramSize = ramSize;
    }


    //getters:
    public String getBrand(){
        return this.brand;
    }

    public int getRamSize(){
        return this.ramSize;
    }

    //setters:
    public void setBrand(String brand){
        this.brand = brand;
    }

    public void setRamSize(int ramSize){
        this.ramSize = ramSize;
    }


    //toString():

    public String toString(){
        return this.brand + " " + this.ramSize;
    }

    //equals():

    public boolean equals(Object obj){
        PC other = (PC)obj;
        return this.brand.equals(other.brand) && this.ramSize == other.ramSize;
    }
}
