public class Student {

    //attributes:
    private int id;
    private String name;
    private double score;
    private char geneder;

    //constructors:
    public Student(){
        this.id = 0;
        this.name = null;
        this.score = 0.0;
        this.geneder = ' ';
    }

    public Student(int id, String name, double score, char geneder){
        this.id = id;
        this.name = name;
        this.score = score;
        this.geneder = geneder;
    }

    //getter:
    public int getId(){
        return this.id;
    }

    public String getName(){
        return this.name;
    }

    public double getScore(){
        return this.score;
    }

    public char getGeneder(){
        return this.geneder;
    }

    //setters:
    public void setId(int id){
        this.id = id;
    }

    public void setName(String name){
        this.name = name;
    }

    public void setScore(double score){
        this.score = score;
    }

    public void setGeneder(char gender){
        this.geneder = gender;
    }

    //toString:
    public String toString(){
        return this.id + " " + this.name + " " + this.score + " " + this.geneder;
    }

    //equals:
    public boolean equals(Object obj){
        Student other = (Student)obj;
        return this.id == other.id && this.name.equals(other.name) &&
                this.score == other.score && this.geneder == other.geneder;
    }

    //finalResult():
    public String finalResult(){
        if(this.score >= 50){
            return "Success";
        }else{
            return "Fail";
        }
    }


}
