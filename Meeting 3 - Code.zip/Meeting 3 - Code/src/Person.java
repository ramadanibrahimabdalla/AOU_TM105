public class Person {
    //attributes:
    private String name;
    private String id;

    //Constructors:
    public Person(String name, String id){
        this.name = name;
        this.id = id;
    }

    public Person(){
        this(null, null);
    }

    //getters:
    public String getName(){
        return this.name;
    }

    public String getId(){
        return this.id;
    }

    //setters:
    public void setName(String name){
        this.name = name;
    }

    public void setId(String id){
        this.id = id;
    }

    //toString():
    public String toString(){
        return "Name is: " + this.name + " Id is: " + this.id;
    }
}
