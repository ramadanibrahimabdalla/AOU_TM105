public class TestPC {
    public static void main(String[] args) {

        //1:
        PC pc1 = new PC("Dell", 4);
        PC pc2 = new PC("HP", 8);

        //2:
        if(pc1.equals(pc2) == true){
            System.out.println("pc1 and pc2 are equals");
        }else{
            System.out.println("pc1 and pc2 are not equal");
        }

        //3:
        pc2.setRamSize(32);

        //4:
        System.out.println(pc1.toString());
    }
}
