public class Building {
    
    //attributes:
    private String address;
    private int numberOfFloors;

    //Constructors:
    public Building(){
        this.address = null;
        this.numberOfFloors = 0;
    }

    public Building(String address, int numberOfFloors){
        this.address = address;
        this.numberOfFloors = numberOfFloors;
    }

    //getters:
    public String getAddress(){
        return this.address;
    }

    public int getNumberOfFloors(){
        return this.numberOfFloors;
    }

    //setters:
    public void setAddress(String address){
        this.address = address;
    }

    public void setNumberOfFloors(int numberOfFloors){
        this.numberOfFloors = numberOfFloors;
    }

    //toString():
    public String toString(){
        return this.address + " " + this.numberOfFloors;
    }
}
