public class TestVehicle {
    public static void main(String[] args) {

        //1:
        Vehicle v1 = new Vehicle("Honda", "ABC123");
        Vehicle v2 = new Vehicle("Toyota", "ABC246");

        //2:
        if(v1.equals(v2)){
            System.out.println("v1 and v2 are equals");
        }else{
            System.out.println("v1 and v2 are not equals");
        }

        //3:
        v2.setBrand("BMW");

        //4:
        System.out.println(v1.toString());
    }
}
