public class Vehicle {

    //attributes:
    private String brand;
    private String plateNumber;

    //Constructors:
    public Vehicle(){
        this.brand = null;
        this.plateNumber = null;
    }

    public Vehicle(String brand, String plateNumber){
        this.brand = brand;
        this.plateNumber = plateNumber;
    }

    //gettes:
    public String getBrand(){
        return this.brand;
    }

    public String getPlateNumber(){
        return this.getPlateNumber();
    }


    //setters:

    public void setBrand(String brand){
        this.brand = brand;
    }

    public void setPlateNumber(String plateNumber){
        this.plateNumber = plateNumber;
    }

    //toString():

    public String toString(){
        return this.brand + " " + this.plateNumber;
    }

    //equals():
    public boolean equals(Object obj){
        Vehicle other = (Vehicle) obj;
        return this.brand.equals(other.brand) && this.plateNumber.equals(other.plateNumber);
    }
}
